/*
 * Exported with nin10kit v1.3
 * Time-stamp: Sunday 11/06/2016, 17:33:55
 * 
 * Image Information
 * -----------------
 * /home/ashwini/Downloads/49690.png 20@20
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * 
 * All bug reports / feature requests are to be sent to Brandon (bwhitehead0308@gmail.com)
 */

#ifndef KIMAVATAR_H
#define KIMAVATAR_H

extern const unsigned short KimAvatar[400];
#define KIMAVATAR_SIZE 400
#define KIMAVATAR_WIDTH 20
#define KIMAVATAR_HEIGHT 20

#endif

