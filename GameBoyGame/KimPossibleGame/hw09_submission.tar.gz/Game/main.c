#include <stdlib.h>
#include "myLib.h"
#include "text.h"

#include "KimStartScreen.h"
#include "KimGameOver.h"
#include "KimAvatar.h"
#include "KimWinScreen.h"



// State enum definition
enum GBAState {
	START,
	START_NODRAW,
	PLAY_GAME,
	GAME_OVER,
	GAME_OVER_NODRAW,
	GAME_WON,
	GAME_WON_NODRAW	
};

int main()
{
	REG_DISPCTL = MODE3 | BG2_ENABLE;
	unsigned int prevButton = 0;
	enum GBAState state = START;
/*	Set up block and obst arrays, initialize them.
	These arrays are set up based on the number of objects and blocks we want. 
	These numbers are set in Lib.h*/
	BLOCK objs[NUMOBJS];
	BLOCK oldobjs[NUMOBJS];
	BLOCK *cur;
	OBST *ob;
	OBST obstacles[NUMOBST];
	//Initialize obstacles
	//There are 3 obstacles
	for (int i = 0; i < NUMOBST; i++) {
		obstacles[i].row = rand()%20 + 10*i*2;
		obstacles[i].col = rand()%20 + 100*i;
		obstacles[i].rd =  10;
		obstacles[i].cd =  20;
		obstacles[i].color = BLUE;	
	}
/*	initialize blocks
	At this point, I am making 1 object
	I still initialize it in an array, so that I 
	can access the info later on easily*/
	for(int i=0; i<NUMOBJS; i++)
	{
		objs[i].row = 100;
		objs[i].col = 100;
		objs[i].rd =  5;
		objs[i].cd =  30;
		objs[i].color = RED;
		oldobjs[i] = objs[i];
	}
	//size of the blocks
	int size = 5;
	u16 bgcolor = BLACK;
	while(1) {
		switch(state) {
			case START:
				drawImage3(0,0,KIMSTARTSCREEN_WIDTH,KIMSTARTSCREEN_HEIGHT,KimStartScreen);
				state = START_NODRAW;
				break;
			case START_NODRAW:
				//if A is pressed play game
				if (KEY_DOWN_NOW(BUTTON_A) && (prevButton != KEY_DOWN_NOW(BUTTON_A))) {
					state = PLAY_GAME;
				}
				break;
			case PLAY_GAME:
				//set background color
				makeBG(bgcolor);
				int gameOver = 0;
				int hasWon = 0;
				//use text to show progression in game
				char *buffer = (char *)("PLAY MODE: In Progress ");
				drawString(150,10,buffer,BLUE);
				//while game is not over or not won yet
				while(!gameOver && !hasWon)
				{
					//initialize cur (current block) and ob (current obstacle)
					cur = objs;
					ob = obstacles;
					//the buttons pressed will move the block in the corresponding direction.
					if(KEY_DOWN_NOW(BUTTON_RIGHT))
					{
						prevButton = KEY_DOWN_NOW(BUTTON_RIGHT);
						if(cur->col > 239-size)
						{
							cur->col = 239-size;
							cur->cd = -cur->cd;
						} else {
							cur->col += 1;
						}
					}
					if(KEY_DOWN_NOW(BUTTON_LEFT))
					{
						prevButton = KEY_DOWN_NOW(BUTTON_LEFT);
						if(cur->col < 0)
						{
							cur->col = 0;
							cur->cd =-cur->cd;
						} else {
							cur->col -= 1;
						}
					}
					if(KEY_DOWN_NOW(BUTTON_UP))
					{
						prevButton = KEY_DOWN_NOW(BUTTON_UP);
						if(cur->row < 0)
						{
							cur->row = 0;
							cur->rd =-cur->rd;
						} else {
							cur->row -= 1;
						}
					}
					if(KEY_DOWN_NOW(BUTTON_DOWN))
					{
						prevButton = KEY_DOWN_NOW(BUTTON_DOWN);
						if(cur->row > MAXROW-size)
						{
							cur->row = 0;
							cur->rd = MAXROW - size;
						} else {
							cur->row += 1;
						}
					}
					//when select is clicked, will go back to start screen
					if (KEY_DOWN_NOW(BUTTON_SELECT) && (prevButton != KEY_DOWN_NOW(BUTTON_SELECT))) {
						prevButton = KEY_DOWN_NOW(BUTTON_SELECT);
						state = START;
						break;
					}
					ob = obstacles;
					waitForVblank();
					//draw black rectangles to cover the red ones
					drawRect(oldobjs->row, oldobjs->col, 5, 5, bgcolor);
					ob = obstacles;
					//game over if it hit an obstacle
					for (int i = 0; i < NUMOBST + 1; i++) {
						gameOver = checkCollison(cur->row, cur->col, ob->row, ob->col, ob->rd, ob->cd,gameOver);
						if(gameOver) {
							state = GAME_OVER;
							break;		
						}

						ob = obstacles + i;
						drawRect(ob->row, ob->col, ob->rd, ob->cd, ob->color);
					}
					//win screen if it hit Kim
					for(int i=0; i<1; i++)
					{
						cur = objs + i;
						drawRect(cur->row, cur->col, size, size, cur->color);
						//draw kim
						drawImage3(0,130,KIMAVATAR_WIDTH,KIMAVATAR_HEIGHT,KimAvatar);
						hasWon = checkCollison(cur->row, cur->col, 0, 130, KIMAVATAR_WIDTH, KIMAVATAR_HEIGHT, hasWon);
						if (hasWon) {
							state = GAME_WON;
							break;
						}
						oldobjs[i] = objs[i];
					}
				}
				break;

			case GAME_OVER:
				drawImage3(0,0,KIMGAMEOVER_WIDTH,KIMGAMEOVER_HEIGHT,KimGameOver);
				buffer = (char *)("PLAY MODE: Game Over ");
				drawString(150,100,buffer,BLACK);
				state = GAME_OVER_NODRAW;
				break;
			case GAME_OVER_NODRAW:
				if (KEY_DOWN_NOW(BUTTON_SELECT) && (prevButton != KEY_DOWN_NOW(BUTTON_SELECT))) {
					prevButton = KEY_DOWN_NOW(BUTTON_SELECT);
					state = START;
				}
				break;
			case GAME_WON:
				drawImage3(0,0,WINSCREEN_WIDTH,WINSCREEN_HEIGHT,WinScreen);
				buffer = (char *)("PLAY MODE: Mission Succeeded! ");
				drawString(150,30,buffer,BLACK);
				state = GAME_WON_NODRAW;
				break;
			case GAME_WON_NODRAW:
				if (KEY_DOWN_NOW(BUTTON_SELECT)) {
					prevButton = KEY_DOWN_NOW(BUTTON_SELECT);
					state = START;
				}
				break;
		}
	}
	return 0;
}
