/*
 * Exported with nin10kit v1.3
 * Time-stamp: Sunday 11/06/2016, 17:27:51
 * 
 * Image Information
 * -----------------
 * /home/ashwini/Desktop/KimStartScreen-2.png 240@160
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * 
 * All bug reports / feature requests are to be sent to Brandon (bwhitehead0308@gmail.com)
 */

#ifndef KIMSTARTSCREEN_H
#define KIMSTARTSCREEN_H

extern const unsigned short KimStartScreen[38400];
#define KIMSTARTSCREEN_SIZE 38400
#define KIMSTARTSCREEN_WIDTH 240
#define KIMSTARTSCREEN_HEIGHT 160

#endif

