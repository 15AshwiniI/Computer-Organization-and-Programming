/*
 * Exported with nin10kit v1.3
 * Time-stamp: Sunday 11/06/2016, 17:23:39
 * 
 * Image Information
 * -----------------
 * /home/ashwini/Desktop/KimGameOver.png 240@160
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * 
 * All bug reports / feature requests are to be sent to Brandon (bwhitehead0308@gmail.com)
 */

#ifndef KIMGAMEOVER_H
#define KIMGAMEOVER_H

extern const unsigned short KimGameOver[38400];
#define KIMGAMEOVER_SIZE 38400
#define KIMGAMEOVER_WIDTH 240
#define KIMGAMEOVER_HEIGHT 160

#endif

