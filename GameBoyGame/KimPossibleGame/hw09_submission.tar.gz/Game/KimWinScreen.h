/*
 * Exported with nin10kit v1.3
 * Time-stamp: Monday 11/07/2016, 21:31:50
 * 
 * Image Information
 * -----------------
 * /home/ashwini/Downloads/WinScreen.png 240@160
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * 
 * All bug reports / feature requests are to be sent to Brandon (bwhitehead0308@gmail.com)
 */

#ifndef KIMWINSCREEN_H
#define KIMWINSCREEN_H

extern const unsigned short WinScreen[38400];
#define WINSCREEN_SIZE 38400
#define WINSCREEN_WIDTH 240
#define WINSCREEN_HEIGHT 160

#endif

