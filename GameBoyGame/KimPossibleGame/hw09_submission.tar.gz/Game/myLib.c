#include "myLib.h"

unsigned short *videoBuffer = (unsigned short *)0x6000000;

/**
* Called when drawing text. Assignes a color to a pixel.
*/
void setPixel(int row, int col, unsigned short color)
{
	videoBuffer[OFFSET(row,col, 240)] = color;
}

/**
* Uses DMA to draw an image in a designated area
*/
void drawImage3(int r, int c, int width, int height, const unsigned short *image) {

	for (int row = 0; row < height; row++) {
		REG_DMA3SAD = (u32)(image+row*width);
		REG_DMA3DAD = (u32)(&videoBuffer[OFFSET(row+r, c, 240)]);
		REG_DMA3CNT = width | DMA_ON | DMA_SOURCE_INCREMENT;
	}
}
/*
* Checks if there has been a collison. If the object is in the range of the obstacle, there has been a collision.
*/
int checkCollison(int objRow, int objCol, int obstRow, int obstCol, int obstRd, int obstCd, int gameOver) {
	
	if (((objRow >= obstRow && objRow <= obstRow + obstRd) && (objCol >= obstCol && objCol <= obstCol + obstCd)) 
		|| (((objRow + 5 >=  obstRow) && (objRow + 5 <= obstRow + obstRd)) &&
			((objCol + 5 >=  obstCol) && (objCol + 5 <= obstCol + obstCd)))) {
		gameOver = 1;
	}
	return gameOver;
		
}

/*
* Draw a rectangle with the given dimensions in the specified color
* uses DMA
*/
void drawRect(int row, int col, int height, int width, volatile unsigned short color)
{
	for(int r=0; r<height; r++)
	{
		REG_DMA3SAD = (u32)&color;
		REG_DMA3DAD = (u32)(&videoBuffer[OFFSET(row+r, col, 240)]);
		REG_DMA3CNT = width | DMA_ON | DMA_SOURCE_FIXED;
	}
}

/**
* Set the gba background color
*/
void makeBG(volatile unsigned short color) {
	REG_DMA3SAD = (u32)&color;
	REG_DMA3DAD = (u32)videoBuffer;
	REG_DMA3CNT = 38400 | DMA_ON | DMA_SOURCE_FIXED;
}

void waitForVblank()
{
	while(SCANLINECOUNTER > 160);
	while(SCANLINECOUNTER < 160);
}

