/*
 * Exported with nin10kit v1.3
 * Time-stamp: Sunday 11/06/2016, 15:10:50
 * 
 * Image Information
 * -----------------
 * /home/ashwini/Desktop/StartScreen.png 240@160
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * 
 * All bug reports / feature requests are to be sent to Brandon (bwhitehead0308@gmail.com)
 */

#ifndef STARTSCREEN_H
#define STARTSCREEN_H

extern const unsigned short StartScreen[38400];
#define STARTSCREEN_SIZE 38400
#define STARTSCREEN_WIDTH 240
#define STARTSCREEN_HEIGHT 160

#endif

