**** README *****

WELCOME TO MY GAME: SAVE KIM!

Backstory:

While trying to foil Dr. Drakken's latest evil scheme, Kim has gotten trapped in an arcade game. It is your job to save her. Use the arrow keys to move the red square to save Kim. The blue rectangles are poisonous, if the red square collides with any of them it is GAME OVER. The moment you reach Kim, you win! You will have successfully saved her and she can continue with her mission!

Game Details:
- BUTTON_UP: Moves the red block up
- BUTTON_DOWN: Moves the red block down
- BUTTON_LEFT: Moves the red block left
- BUTTON_RIGHT: Moves the red block right
- When you are at the Start Screen, press BUTTON_A to start playing
- During the course of the game, if you are either at the game over screen or are playing, press BUTTON_SELECT
to return to the start screen.

- This game includes 2 structs (BLOCK and OBST) located in myLib.h
- The movement of the red block shows two dimensional movement because it can move up, down, right and left
- Object collision is used to determine if the red block has collided with Kim or the poisonous blue rectangles.
- Text has been used to show progression in my game. It shows the status of the game: if you are in play mode then the status will show that, and if you are in game over it will show that.
